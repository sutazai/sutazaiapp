--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

-- Started on 2025-08-09 23:28:53 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.tasks DROP CONSTRAINT tasks_user_id_fkey;
ALTER TABLE ONLY public.tasks DROP CONSTRAINT tasks_agent_id_fkey;
ALTER TABLE ONLY public.system_alerts DROP CONSTRAINT system_alerts_resolved_by_fkey;
ALTER TABLE ONLY public.sessions DROP CONSTRAINT sessions_user_id_fkey;
ALTER TABLE ONLY public.chat_history DROP CONSTRAINT chat_history_user_id_fkey;
ALTER TABLE ONLY public.agent_health DROP CONSTRAINT agent_health_agent_id_fkey;
ALTER TABLE ONLY public.agent_executions DROP CONSTRAINT agent_executions_task_id_fkey;
ALTER TABLE ONLY public.agent_executions DROP CONSTRAINT agent_executions_agent_id_fkey;
DROP TRIGGER update_users_updated_at ON public.users;
DROP TRIGGER update_tasks_updated_at ON public.tasks;
DROP TRIGGER update_agents_updated_at ON public.agents;
DROP INDEX public.idx_users_username;
DROP INDEX public.idx_users_is_admin;
DROP INDEX public.idx_users_email;
DROP INDEX public.idx_tasks_user_id;
DROP INDEX public.idx_tasks_status;
DROP INDEX public.idx_tasks_agent_id;
DROP INDEX public.idx_system_metrics_recorded_at;
DROP INDEX public.idx_system_metrics_name;
DROP INDEX public.idx_system_alerts_status;
DROP INDEX public.idx_sessions_user_id;
DROP INDEX public.idx_sessions_token;
DROP INDEX public.idx_model_registry_name;
DROP INDEX public.idx_chat_history_user_id;
DROP INDEX public.idx_agents_type;
DROP INDEX public.idx_agent_health_status;
DROP INDEX public.idx_agent_health_agent_id;
DROP INDEX public.idx_agent_executions_agent_id;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_username_key;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.tasks DROP CONSTRAINT tasks_pkey;
ALTER TABLE ONLY public.system_metrics DROP CONSTRAINT system_metrics_pkey;
ALTER TABLE ONLY public.system_alerts DROP CONSTRAINT system_alerts_pkey;
ALTER TABLE ONLY public.sessions DROP CONSTRAINT sessions_token_key;
ALTER TABLE ONLY public.sessions DROP CONSTRAINT sessions_pkey;
ALTER TABLE ONLY public.model_registry DROP CONSTRAINT model_registry_pkey;
ALTER TABLE ONLY public.model_registry DROP CONSTRAINT model_registry_model_name_key;
ALTER TABLE ONLY public.chat_history DROP CONSTRAINT chat_history_pkey;
ALTER TABLE ONLY public.agents DROP CONSTRAINT agents_pkey;
ALTER TABLE ONLY public.agents DROP CONSTRAINT agents_name_key;
ALTER TABLE ONLY public.agent_health DROP CONSTRAINT agent_health_pkey;
ALTER TABLE ONLY public.agent_executions DROP CONSTRAINT agent_executions_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tasks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.system_metrics ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.system_alerts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.model_registry ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.chat_history ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.agents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.agent_health ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.agent_executions ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.tasks_id_seq;
DROP TABLE public.tasks;
DROP SEQUENCE public.system_metrics_id_seq;
DROP TABLE public.system_metrics;
DROP SEQUENCE public.system_alerts_id_seq;
DROP TABLE public.system_alerts;
DROP SEQUENCE public.sessions_id_seq;
DROP TABLE public.sessions;
DROP SEQUENCE public.model_registry_id_seq;
DROP TABLE public.model_registry;
DROP SEQUENCE public.chat_history_id_seq;
DROP TABLE public.chat_history;
DROP SEQUENCE public.agents_id_seq;
DROP TABLE public.agents;
DROP SEQUENCE public.agent_health_id_seq;
DROP TABLE public.agent_health;
DROP SEQUENCE public.agent_executions_id_seq;
DROP TABLE public.agent_executions;
DROP FUNCTION public.update_updated_at_column();
DROP EXTENSION "uuid-ossp";
DROP EXTENSION pgcrypto;
--
-- TOC entry 3 (class 3079 OID 24677)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- TOC entry 3616 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- TOC entry 2 (class 3079 OID 24666)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 3617 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 248 (class 1255 OID 24662)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 226 (class 1259 OID 24735)
-- Name: agent_executions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_executions (
    id integer NOT NULL,
    agent_id integer,
    task_id integer,
    status character varying(50),
    input_data jsonb,
    output_data jsonb,
    execution_time double precision,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 225 (class 1259 OID 24734)
-- Name: agent_executions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_executions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3618 (class 0 OID 0)
-- Dependencies: 225
-- Name: agent_executions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agent_executions_id_seq OWNED BY public.agent_executions.id;


--
-- TOC entry 232 (class 1259 OID 24790)
-- Name: agent_health; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_health (
    id integer NOT NULL,
    agent_id integer,
    status character varying(50) DEFAULT 'unknown'::character varying NOT NULL,
    last_heartbeat timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cpu_usage numeric(5,2) DEFAULT 0.00,
    memory_usage numeric(5,2) DEFAULT 0.00,
    disk_usage numeric(5,2) DEFAULT 0.00,
    response_time numeric(8,3) DEFAULT 0.000,
    error_count integer DEFAULT 0,
    success_count integer DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 231 (class 1259 OID 24789)
-- Name: agent_health_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_health_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3619 (class 0 OID 0)
-- Dependencies: 231
-- Name: agent_health_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agent_health_id_seq OWNED BY public.agent_health.id;


--
-- TOC entry 220 (class 1259 OID 24591)
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    endpoint character varying(255) NOT NULL,
    port integer,
    is_active boolean DEFAULT true,
    capabilities jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 219 (class 1259 OID 24590)
-- Name: agents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3620 (class 0 OID 0)
-- Dependencies: 219
-- Name: agents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agents_id_seq OWNED BY public.agents.id;


--
-- TOC entry 224 (class 1259 OID 24720)
-- Name: chat_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_history (
    id integer NOT NULL,
    user_id integer,
    message text NOT NULL,
    response text,
    agent_used character varying(100),
    tokens_used integer,
    response_time double precision,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 223 (class 1259 OID 24719)
-- Name: chat_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3621 (class 0 OID 0)
-- Dependencies: 223
-- Name: chat_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_history_id_seq OWNED BY public.chat_history.id;


--
-- TOC entry 234 (class 1259 OID 24815)
-- Name: model_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_registry (
    id integer NOT NULL,
    model_name character varying(255) NOT NULL,
    model_type character varying(100) NOT NULL,
    size_mb numeric(10,2),
    status character varying(50) DEFAULT 'available'::character varying,
    ollama_status character varying(50),
    usage_count integer DEFAULT 0,
    last_used timestamp without time zone,
    file_path text,
    parameters jsonb DEFAULT '{}'::jsonb,
    capabilities jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 233 (class 1259 OID 24814)
-- Name: model_registry_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_registry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3622 (class 0 OID 0)
-- Dependencies: 233
-- Name: model_registry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_registry_id_seq OWNED BY public.model_registry.id;


--
-- TOC entry 230 (class 1259 OID 24771)
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    user_id integer,
    token character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    is_active boolean DEFAULT true,
    user_agent text,
    ip_address inet,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_accessed timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 229 (class 1259 OID 24770)
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3623 (class 0 OID 0)
-- Dependencies: 229
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- TOC entry 236 (class 1259 OID 24832)
-- Name: system_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_alerts (
    id integer NOT NULL,
    alert_type character varying(100) NOT NULL,
    severity character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    source character varying(100),
    status character varying(50) DEFAULT 'active'::character varying,
    resolved_at timestamp without time zone,
    resolved_by integer,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 235 (class 1259 OID 24831)
-- Name: system_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3624 (class 0 OID 0)
-- Dependencies: 235
-- Name: system_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_alerts_id_seq OWNED BY public.system_alerts.id;


--
-- TOC entry 228 (class 1259 OID 24755)
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_metrics (
    id integer NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_value double precision NOT NULL,
    tags jsonb DEFAULT '{}'::jsonb,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 227 (class 1259 OID 24754)
-- Name: system_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3625 (class 0 OID 0)
-- Dependencies: 227
-- Name: system_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_metrics_id_seq OWNED BY public.system_metrics.id;


--
-- TOC entry 222 (class 1259 OID 24605)
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    agent_id integer,
    user_id integer,
    status character varying(50) DEFAULT 'pending'::character varying,
    priority integer DEFAULT 5,
    payload jsonb DEFAULT '{}'::jsonb,
    result jsonb,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    started_at timestamp without time zone,
    completed_at timestamp without time zone
);


--
-- TOC entry 221 (class 1259 OID 24604)
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3626 (class 0 OID 0)
-- Dependencies: 221
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- TOC entry 218 (class 1259 OID 24577)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_admin boolean DEFAULT false,
    last_login timestamp with time zone,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone
);


--
-- TOC entry 217 (class 1259 OID 24576)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3627 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 3357 (class 2604 OID 24738)
-- Name: agent_executions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_executions ALTER COLUMN id SET DEFAULT nextval('public.agent_executions_id_seq'::regclass);


--
-- TOC entry 3366 (class 2604 OID 24793)
-- Name: agent_health id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_health ALTER COLUMN id SET DEFAULT nextval('public.agent_health_id_seq'::regclass);


--
-- TOC entry 3346 (class 2604 OID 24594)
-- Name: agents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents ALTER COLUMN id SET DEFAULT nextval('public.agents_id_seq'::regclass);


--
-- TOC entry 3355 (class 2604 OID 24723)
-- Name: chat_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_history ALTER COLUMN id SET DEFAULT nextval('public.chat_history_id_seq'::regclass);


--
-- TOC entry 3378 (class 2604 OID 24818)
-- Name: model_registry id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_registry ALTER COLUMN id SET DEFAULT nextval('public.model_registry_id_seq'::regclass);


--
-- TOC entry 3362 (class 2604 OID 24774)
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- TOC entry 3385 (class 2604 OID 24835)
-- Name: system_alerts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alerts ALTER COLUMN id SET DEFAULT nextval('public.system_alerts_id_seq'::regclass);


--
-- TOC entry 3359 (class 2604 OID 24758)
-- Name: system_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_metrics ALTER COLUMN id SET DEFAULT nextval('public.system_metrics_id_seq'::regclass);


--
-- TOC entry 3350 (class 2604 OID 24608)
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- TOC entry 3340 (class 2604 OID 24580)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3600 (class 0 OID 24735)
-- Dependencies: 226
-- Data for Name: agent_executions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_executions (id, agent_id, task_id, status, input_data, output_data, execution_time, error_message, created_at) FROM stdin;
\.


--
-- TOC entry 3606 (class 0 OID 24790)
-- Dependencies: 232
-- Data for Name: agent_health; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_health (id, agent_id, status, last_heartbeat, cpu_usage, memory_usage, disk_usage, response_time, error_count, success_count, metadata, created_at, updated_at) FROM stdin;
1	1	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
2	2	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
3	3	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
4	4	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
5	5	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
6	4	healthy	2025-08-09 23:25:19.417967	25.50	512.70	0.00	0.125	0	0	{}	2025-08-09 23:25:19.417967	2025-08-09 23:25:19.417967
\.


--
-- TOC entry 3594 (class 0 OID 24591)
-- Dependencies: 220
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agents (id, name, type, description, endpoint, port, is_active, capabilities, created_at) FROM stdin;
1	health-monitor	monitoring	\N	http://health-monitor:8080	10210	t	["health_check", "metrics"]	2025-08-09 11:48:02.541621
2	task-coordinator	orchestration	\N	http://task-coordinator:8080	10450	t	["task_routing", "scheduling"]	2025-08-09 11:48:02.541621
3	ollama-service	llm	\N	http://ollama:11434	11434	t	["text_generation", "chat"]	2025-08-09 11:48:02.541621
4	hardware-resource-optimizer	optimization	\N	http://hardware-resource-optimizer:8080	11110	t	["resource_monitoring", "optimization"]	2025-08-09 11:48:02.541621
5	ai-agent-orchestrator	orchestration	\N	http://ai-agent-orchestrator:8080	8589	t	["agent_coordination", "task_routing"]	2025-08-09 11:48:02.541621
\.


--
-- TOC entry 3598 (class 0 OID 24720)
-- Dependencies: 224
-- Data for Name: chat_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_history (id, user_id, message, response, agent_used, tokens_used, response_time, created_at) FROM stdin;
\.


--
-- TOC entry 3608 (class 0 OID 24815)
-- Dependencies: 234
-- Data for Name: model_registry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_registry (id, model_name, model_type, size_mb, status, ollama_status, usage_count, last_used, file_path, parameters, capabilities, created_at, updated_at) FROM stdin;
1	tinyllama	llm	637.00	active	loaded	0	\N	\N	{"parameters": "1.1B", "quantization": "Q4_0", "context_length": 2048}	[]	2025-08-09 23:24:07.022462	2025-08-09 23:24:07.022462
\.


--
-- TOC entry 3604 (class 0 OID 24771)
-- Dependencies: 230
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, user_id, token, expires_at, is_active, user_agent, ip_address, created_at, last_accessed) FROM stdin;
\.


--
-- TOC entry 3610 (class 0 OID 24832)
-- Dependencies: 236
-- Data for Name: system_alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_alerts (id, alert_type, severity, title, description, source, status, resolved_at, resolved_by, metadata, created_at) FROM stdin;
1	database_test	info	Database Schema Initialization Complete	All tables created and initialized successfully	dba_admin	active	\N	\N	{}	2025-08-09 23:25:19.417967
\.


--
-- TOC entry 3602 (class 0 OID 24755)
-- Dependencies: 228
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_metrics (id, metric_name, metric_value, tags, recorded_at) FROM stdin;
\.


--
-- TOC entry 3596 (class 0 OID 24605)
-- Dependencies: 222
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks (id, title, description, agent_id, user_id, status, priority, payload, result, error_message, created_at, started_at, completed_at) FROM stdin;
\.


--
-- TOC entry 3592 (class 0 OID 24577)
-- Dependencies: 218
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, password_hash, is_active, created_at, updated_at, is_admin, last_login, failed_login_attempts, locked_until) FROM stdin;
2	system	system@sutazai.local	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewjyJyM7QK8kL5yC	t	2025-08-09 08:33:14.678865+00	2025-08-09 08:33:14.678865+00	f	\N	0	\N
4	testuser	test@example.com	$2b$12$Bb3F5df4b.a8srdVrs8tDeORK/f0.tQbfAMhf.WKHEdQAiGHHDtOO	t	2025-08-09 11:35:06.146473+00	2025-08-09 11:35:28.8902+00	f	2025-08-09 11:35:28.890943+00	0	\N
5	testuser3	test3@example.com	$2b$12$evgZb/VZLlUNKtPlMoBToO6OMYuRt63k9k0LwhzbOsModyr41UONW	t	2025-08-09 11:46:54.876466+00	2025-08-09 11:47:08.542303+00	f	2025-08-09 11:47:08.543288+00	0	\N
1	admin	admin@sutazai.local	$2b$12$NPu5JmL4gBSR21BQRYDoW.xzKoWyatlrbchYKuQes7kpsLb2zoBNG	t	2025-08-09 08:33:14.678865+00	2025-08-09 23:24:59.685658+00	t	\N	2	\N
7	dba_test	dba_test@sutazai.local	test_hash	t	2025-08-09 23:25:19.417967+00	2025-08-09 23:25:19.417967+00	f	\N	0	\N
\.


--
-- TOC entry 3628 (class 0 OID 0)
-- Dependencies: 225
-- Name: agent_executions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_executions_id_seq', 1, false);


--
-- TOC entry 3629 (class 0 OID 0)
-- Dependencies: 231
-- Name: agent_health_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_health_id_seq', 6, true);


--
-- TOC entry 3630 (class 0 OID 0)
-- Dependencies: 219
-- Name: agents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agents_id_seq', 5, true);


--
-- TOC entry 3631 (class 0 OID 0)
-- Dependencies: 223
-- Name: chat_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_history_id_seq', 1, false);


--
-- TOC entry 3632 (class 0 OID 0)
-- Dependencies: 233
-- Name: model_registry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_registry_id_seq', 1, true);


--
-- TOC entry 3633 (class 0 OID 0)
-- Dependencies: 229
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sessions_id_seq', 1, false);


--
-- TOC entry 3634 (class 0 OID 0)
-- Dependencies: 235
-- Name: system_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_alerts_id_seq', 1, true);


--
-- TOC entry 3635 (class 0 OID 0)
-- Dependencies: 227
-- Name: system_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_metrics_id_seq', 1, false);


--
-- TOC entry 3636 (class 0 OID 0)
-- Dependencies: 221
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- TOC entry 3637 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 7, true);


--
-- TOC entry 3413 (class 2606 OID 24743)
-- Name: agent_executions agent_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_pkey PRIMARY KEY (id);


--
-- TOC entry 3426 (class 2606 OID 24808)
-- Name: agent_health agent_health_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_health
    ADD CONSTRAINT agent_health_pkey PRIMARY KEY (id);


--
-- TOC entry 3400 (class 2606 OID 24603)
-- Name: agents agents_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_name_key UNIQUE (name);


--
-- TOC entry 3402 (class 2606 OID 24601)
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- TOC entry 3410 (class 2606 OID 24728)
-- Name: chat_history chat_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_history
    ADD CONSTRAINT chat_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3431 (class 2606 OID 24830)
-- Name: model_registry model_registry_model_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_model_name_key UNIQUE (model_name);


--
-- TOC entry 3433 (class 2606 OID 24828)
-- Name: model_registry model_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_pkey PRIMARY KEY (id);


--
-- TOC entry 3422 (class 2606 OID 24781)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3424 (class 2606 OID 24783)
-- Name: sessions sessions_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_token_key UNIQUE (token);


--
-- TOC entry 3436 (class 2606 OID 24843)
-- Name: system_alerts system_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_pkey PRIMARY KEY (id);


--
-- TOC entry 3418 (class 2606 OID 24764)
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3408 (class 2606 OID 24616)
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- TOC entry 3394 (class 2606 OID 24589)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3396 (class 2606 OID 24585)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3398 (class 2606 OID 24587)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 3414 (class 1259 OID 24766)
-- Name: idx_agent_executions_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_executions_agent_id ON public.agent_executions USING btree (agent_id);


--
-- TOC entry 3427 (class 1259 OID 24852)
-- Name: idx_agent_health_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_health_agent_id ON public.agent_health USING btree (agent_id);


--
-- TOC entry 3428 (class 1259 OID 24853)
-- Name: idx_agent_health_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_health_status ON public.agent_health USING btree (status);


--
-- TOC entry 3403 (class 1259 OID 24660)
-- Name: idx_agents_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agents_type ON public.agents USING btree (type);


--
-- TOC entry 3411 (class 1259 OID 24765)
-- Name: idx_chat_history_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_history_user_id ON public.chat_history USING btree (user_id);


--
-- TOC entry 3429 (class 1259 OID 24855)
-- Name: idx_model_registry_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_registry_name ON public.model_registry USING btree (model_name);


--
-- TOC entry 3419 (class 1259 OID 24851)
-- Name: idx_sessions_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_token ON public.sessions USING btree (token);


--
-- TOC entry 3420 (class 1259 OID 24850)
-- Name: idx_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_user_id ON public.sessions USING btree (user_id);


--
-- TOC entry 3434 (class 1259 OID 24854)
-- Name: idx_system_alerts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_alerts_status ON public.system_alerts USING btree (status);


--
-- TOC entry 3415 (class 1259 OID 24767)
-- Name: idx_system_metrics_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_metrics_name ON public.system_metrics USING btree (metric_name);


--
-- TOC entry 3416 (class 1259 OID 24768)
-- Name: idx_system_metrics_recorded_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_metrics_recorded_at ON public.system_metrics USING btree (recorded_at);


--
-- TOC entry 3404 (class 1259 OID 24661)
-- Name: idx_tasks_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_agent_id ON public.tasks USING btree (agent_id);


--
-- TOC entry 3405 (class 1259 OID 24627)
-- Name: idx_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_status ON public.tasks USING btree (status);


--
-- TOC entry 3406 (class 1259 OID 24628)
-- Name: idx_tasks_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_user_id ON public.tasks USING btree (user_id);


--
-- TOC entry 3390 (class 1259 OID 24658)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3391 (class 1259 OID 24716)
-- Name: idx_users_is_admin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_is_admin ON public.users USING btree (is_admin) WHERE (is_admin = true);


--
-- TOC entry 3392 (class 1259 OID 24659)
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- TOC entry 3446 (class 2620 OID 24664)
-- Name: agents update_agents_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_agents_updated_at BEFORE UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3447 (class 2620 OID 24665)
-- Name: tasks update_tasks_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3445 (class 2620 OID 24663)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3440 (class 2606 OID 24744)
-- Name: agent_executions agent_executions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- TOC entry 3441 (class 2606 OID 24749)
-- Name: agent_executions agent_executions_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- TOC entry 3443 (class 2606 OID 24809)
-- Name: agent_health agent_health_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_health
    ADD CONSTRAINT agent_health_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- TOC entry 3439 (class 2606 OID 24729)
-- Name: chat_history chat_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_history
    ADD CONSTRAINT chat_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3442 (class 2606 OID 24784)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3444 (class 2606 OID 24844)
-- Name: system_alerts system_alerts_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- TOC entry 3437 (class 2606 OID 24617)
-- Name: tasks tasks_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- TOC entry 3438 (class 2606 OID 24622)
-- Name: tasks tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


-- Completed on 2025-08-09 23:28:54 UTC

--
-- PostgreSQL database dump complete
--

