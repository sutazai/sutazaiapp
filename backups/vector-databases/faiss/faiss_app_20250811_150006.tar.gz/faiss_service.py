from fastapi import FastAPI
from fastapi.responses import JSONResponse
import faiss
import numpy as np
import uvicorn

app = FastAPI(title="FAISS Vector Database Service")

# Initialize FAISS index
index = None
dimension = 384  # Default embedding dimension

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "faiss-vector-db"}

@app.post("/create_index")
async def create_index(dim: int = 384):
    global index, dimension
    dimension = dim
    index = faiss.IndexFlatL2(dimension)
    return {"status": "index_created", "dimension": dimension}

@app.post("/add_vectors")
async def add_vectors(vectors: list):
    global index
    if index is None:
        index = faiss.IndexFlatL2(len(vectors[0]))
    
    vectors_array = np.array(vectors, dtype=np.float32)
    index.add(vectors_array)
    return {"status": "vectors_added", "count": len(vectors)}

@app.post("/search")
async def search_vectors(query_vector: list, k: int = 5):
    global index
    if index is None:
        return {"error": "Index not initialized"}
    
    query_array = np.array([query_vector], dtype=np.float32)
    distances, indices = index.search(query_array, k)
    
    return {
        "distances": distances[0].tolist(),
        "indices": indices[0].tolist()
    }

@app.get("/info")
async def get_info():
    global index, dimension
    return {
        "dimension": dimension,
        "total_vectors": index.ntotal if index else 0,
        "index_type": "IndexFlatL2"
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
