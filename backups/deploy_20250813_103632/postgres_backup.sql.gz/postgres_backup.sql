--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: sutazai
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO sutazai;

--
-- Name: verify_schema_migration(); Type: FUNCTION; Schema: public; Owner: sutazai
--

CREATE FUNCTION public.verify_schema_migration() RETURNS TABLE(table_count integer, uuid_tables integer, indexed_tables integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        (SELECT COUNT(*)::INTEGER FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE') as table_count,
        (SELECT COUNT(*)::INTEGER FROM information_schema.columns c 
         JOIN information_schema.tables t ON c.table_name = t.table_name 
         WHERE t.table_schema = 'public' AND c.column_name = 'id' AND c.data_type = 'uuid') as uuid_tables,
        (SELECT COUNT(DISTINCT tablename)::INTEGER FROM pg_indexes WHERE schemaname = 'public') as indexed_tables;
END;
$$;


ALTER FUNCTION public.verify_schema_migration() OWNER TO sutazai;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_communication; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.agent_communication (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    from_agent_id uuid,
    to_agent_id uuid,
    message_type character varying(50) NOT NULL,
    message_body jsonb NOT NULL,
    status character varying(20) DEFAULT 'sent'::character varying,
    priority integer DEFAULT 5,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    delivered_at timestamp with time zone,
    acknowledged_at timestamp with time zone
);


ALTER TABLE public.agent_communication OWNER TO sutazai;

--
-- Name: agent_configurations; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.agent_configurations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    agent_id uuid,
    config_name character varying(100) NOT NULL,
    config_data jsonb NOT NULL,
    version integer DEFAULT 1,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    activated_at timestamp with time zone
);


ALTER TABLE public.agent_configurations OWNER TO sutazai;

--
-- Name: agent_executions; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.agent_executions (
    id integer NOT NULL,
    agent_id integer,
    task_id integer,
    status character varying(50),
    input_data jsonb,
    output_data jsonb,
    execution_time double precision,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.agent_executions OWNER TO sutazai;

--
-- Name: agent_executions_id_seq; Type: SEQUENCE; Schema: public; Owner: sutazai
--

CREATE SEQUENCE public.agent_executions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_executions_id_seq OWNER TO sutazai;

--
-- Name: agent_executions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sutazai
--

ALTER SEQUENCE public.agent_executions_id_seq OWNED BY public.agent_executions.id;


--
-- Name: agent_health; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.agent_health (
    id integer NOT NULL,
    agent_id integer,
    status character varying(50) DEFAULT 'unknown'::character varying NOT NULL,
    last_heartbeat timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cpu_usage numeric(5,2) DEFAULT 0.00,
    memory_usage numeric(5,2) DEFAULT 0.00,
    disk_usage numeric(5,2) DEFAULT 0.00,
    response_time numeric(8,3) DEFAULT 0.000,
    error_count integer DEFAULT 0,
    success_count integer DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.agent_health OWNER TO sutazai;

--
-- Name: agent_health_id_seq; Type: SEQUENCE; Schema: public; Owner: sutazai
--

CREATE SEQUENCE public.agent_health_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_health_id_seq OWNER TO sutazai;

--
-- Name: agent_health_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sutazai
--

ALTER SEQUENCE public.agent_health_id_seq OWNED BY public.agent_health.id;


--
-- Name: agents; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.agents (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    endpoint character varying(255) NOT NULL,
    port integer,
    is_active boolean DEFAULT true,
    capabilities jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.agents OWNER TO sutazai;

--
-- Name: agents_id_seq; Type: SEQUENCE; Schema: public; Owner: sutazai
--

CREATE SEQUENCE public.agents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agents_id_seq OWNER TO sutazai;

--
-- Name: agents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sutazai
--

ALTER SEQUENCE public.agents_id_seq OWNED BY public.agents.id;


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    key_name character varying(100) NOT NULL,
    key_hash character varying(255) NOT NULL,
    key_prefix character varying(20) NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb,
    rate_limit_per_minute integer DEFAULT 60,
    last_used_at timestamp with time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    CONSTRAINT chk_rate_limit CHECK (((rate_limit_per_minute >= 0) AND (rate_limit_per_minute <= 10000)))
);


ALTER TABLE public.api_keys OWNER TO sutazai;

--
-- Name: api_usage_logs; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.api_usage_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    endpoint character varying(255) NOT NULL,
    method character varying(10) NOT NULL,
    user_id uuid,
    agent_id uuid,
    response_code integer,
    response_time numeric(8,3),
    request_size integer,
    response_size integer,
    ip_address inet,
    user_agent text,
    headers jsonb DEFAULT '{}'::jsonb,
    request_body text,
    response_body text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.api_usage_logs OWNER TO sutazai;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    resource_type character varying(50),
    resource_id uuid,
    old_values jsonb,
    new_values jsonb,
    ip_address inet,
    user_agent text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_logs OWNER TO sutazai;

--
-- Name: backup_executions; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.backup_executions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    job_id uuid,
    execution_status character varying(20) DEFAULT 'running'::character varying,
    backup_size_mb numeric(10,2),
    duration_seconds integer,
    error_message text,
    backup_location character varying(1000),
    checksum character varying(255),
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp with time zone
);


ALTER TABLE public.backup_executions OWNER TO sutazai;

--
-- Name: backup_jobs; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.backup_jobs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    job_name character varying(255) NOT NULL,
    backup_type character varying(50) NOT NULL,
    source_config jsonb NOT NULL,
    destination_config jsonb NOT NULL,
    schedule_cron character varying(100),
    retention_days integer DEFAULT 30,
    status character varying(20) DEFAULT 'active'::character varying,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.backup_jobs OWNER TO sutazai;

--
-- Name: cache_entries; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.cache_entries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    cache_key character varying(500) NOT NULL,
    cache_value text,
    cache_type character varying(50) DEFAULT 'string'::character varying,
    ttl_seconds integer DEFAULT 3600,
    access_count integer DEFAULT 0,
    last_accessed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone
);


ALTER TABLE public.cache_entries OWNER TO sutazai;

--
-- Name: chat_history; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.chat_history (
    id integer NOT NULL,
    user_id integer,
    message text NOT NULL,
    response text,
    agent_used character varying(100),
    tokens_used integer,
    response_time double precision,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.chat_history OWNER TO sutazai;

--
-- Name: chat_history_id_seq; Type: SEQUENCE; Schema: public; Owner: sutazai
--

CREATE SEQUENCE public.chat_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_history_id_seq OWNER TO sutazai;

--
-- Name: chat_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sutazai
--

ALTER SEQUENCE public.chat_history_id_seq OWNED BY public.chat_history.id;


--
-- Name: data_pipelines; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.data_pipelines (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    pipeline_name character varying(255) NOT NULL,
    source_id uuid,
    destination_id uuid,
    pipeline_config jsonb NOT NULL,
    schedule_cron character varying(100),
    status character varying(20) DEFAULT 'active'::character varying,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.data_pipelines OWNER TO sutazai;

--
-- Name: data_quality_checks; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.data_quality_checks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    source_id uuid,
    check_name character varying(255) NOT NULL,
    check_type character varying(50) NOT NULL,
    check_config jsonb DEFAULT '{}'::jsonb,
    threshold_config jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.data_quality_checks OWNER TO sutazai;

--
-- Name: data_quality_results; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.data_quality_results (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    check_id uuid,
    execution_timestamp timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    passed boolean,
    score numeric(5,4),
    details jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT chk_score_range CHECK (((score >= 0.0) AND (score <= 1.0)))
);


ALTER TABLE public.data_quality_results OWNER TO sutazai;

--
-- Name: data_sources; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.data_sources (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    source_name character varying(255) NOT NULL,
    source_type character varying(50) NOT NULL,
    connection_string character varying(1000),
    credentials jsonb DEFAULT '{}'::jsonb,
    schema_definition jsonb DEFAULT '{}'::jsonb,
    status character varying(20) DEFAULT 'active'::character varying,
    last_sync_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.data_sources OWNER TO sutazai;

--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.feature_flags (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    flag_name character varying(255) NOT NULL,
    description text,
    is_enabled boolean DEFAULT false,
    rollout_percentage integer DEFAULT 0,
    target_users jsonb DEFAULT '[]'::jsonb,
    conditions jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid
);


ALTER TABLE public.feature_flags OWNER TO sutazai;

--
-- Name: incident_timeline; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.incident_timeline (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    incident_id uuid,
    event_type character varying(50) NOT NULL,
    event_description text NOT NULL,
    created_by uuid,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.incident_timeline OWNER TO sutazai;

--
-- Name: incidents; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.incidents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    incident_title character varying(500) NOT NULL,
    description text,
    severity character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'open'::character varying,
    affected_services jsonb DEFAULT '[]'::jsonb,
    assigned_to uuid,
    reported_by uuid,
    root_cause text,
    resolution text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    resolved_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.incidents OWNER TO sutazai;

--
-- Name: integration_endpoints; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.integration_endpoints (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    endpoint_name character varying(255) NOT NULL,
    endpoint_type character varying(100) NOT NULL,
    base_url character varying(1000) NOT NULL,
    authentication_config jsonb DEFAULT '{}'::jsonb,
    headers_config jsonb DEFAULT '{}'::jsonb,
    rate_limit_config jsonb DEFAULT '{}'::jsonb,
    timeout_seconds integer DEFAULT 30,
    retry_config jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.integration_endpoints OWNER TO sutazai;

--
-- Name: integration_logs; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.integration_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    endpoint_id uuid,
    request_method character varying(10) NOT NULL,
    request_url character varying(1000) NOT NULL,
    request_headers jsonb DEFAULT '{}'::jsonb,
    request_body text,
    response_status integer,
    response_headers jsonb DEFAULT '{}'::jsonb,
    response_body text,
    duration_ms integer,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.integration_logs OWNER TO sutazai;

--
-- Name: knowledge_documents; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.knowledge_documents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(500),
    content_preview text,
    full_content text,
    document_type character varying(100),
    source_path character varying(1000),
    collection_id uuid,
    embedding_status character varying(50) DEFAULT 'pending'::character varying,
    processed_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.knowledge_documents OWNER TO sutazai;

--
-- Name: migration_backup_agent_executions; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.migration_backup_agent_executions (
    id integer,
    agent_id integer,
    task_id integer,
    status character varying(50),
    input_data jsonb,
    output_data jsonb,
    execution_time double precision,
    error_message text,
    created_at timestamp without time zone
);


ALTER TABLE public.migration_backup_agent_executions OWNER TO sutazai;

--
-- Name: migration_backup_agent_health; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.migration_backup_agent_health (
    id integer,
    agent_id integer,
    status character varying(50),
    last_heartbeat timestamp without time zone,
    cpu_usage numeric(5,2),
    memory_usage numeric(5,2),
    disk_usage numeric(5,2),
    response_time numeric(8,3),
    error_count integer,
    success_count integer,
    metadata jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.migration_backup_agent_health OWNER TO sutazai;

--
-- Name: migration_backup_agents; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.migration_backup_agents (
    id integer,
    name character varying(100),
    type character varying(50),
    description text,
    endpoint character varying(255),
    port integer,
    is_active boolean,
    capabilities jsonb,
    created_at timestamp without time zone
);


ALTER TABLE public.migration_backup_agents OWNER TO sutazai;

--
-- Name: migration_backup_chat_history; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.migration_backup_chat_history (
    id integer,
    user_id integer,
    message text,
    response text,
    agent_used character varying(100),
    tokens_used integer,
    response_time double precision,
    created_at timestamp without time zone
);


ALTER TABLE public.migration_backup_chat_history OWNER TO sutazai;

--
-- Name: migration_backup_model_registry; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.migration_backup_model_registry (
    id integer,
    model_name character varying(255),
    model_type character varying(100),
    size_mb numeric(10,2),
    status character varying(50),
    ollama_status character varying(50),
    usage_count integer,
    last_used timestamp without time zone,
    file_path text,
    parameters jsonb,
    capabilities jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.migration_backup_model_registry OWNER TO sutazai;

--
-- Name: migration_backup_sessions; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.migration_backup_sessions (
    id integer,
    user_id integer,
    token character varying(255),
    expires_at timestamp without time zone,
    is_active boolean,
    user_agent text,
    ip_address inet,
    created_at timestamp without time zone,
    last_accessed timestamp without time zone
);


ALTER TABLE public.migration_backup_sessions OWNER TO sutazai;

--
-- Name: migration_backup_system_alerts; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.migration_backup_system_alerts (
    id integer,
    alert_type character varying(100),
    severity character varying(20),
    title character varying(255),
    description text,
    source character varying(100),
    status character varying(50),
    resolved_at timestamp without time zone,
    resolved_by integer,
    metadata jsonb,
    created_at timestamp without time zone
);


ALTER TABLE public.migration_backup_system_alerts OWNER TO sutazai;

--
-- Name: migration_backup_system_metrics; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.migration_backup_system_metrics (
    id integer,
    metric_name character varying(100),
    metric_value double precision,
    tags jsonb,
    recorded_at timestamp without time zone
);


ALTER TABLE public.migration_backup_system_metrics OWNER TO sutazai;

--
-- Name: migration_backup_tasks; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.migration_backup_tasks (
    id integer,
    title character varying(255),
    description text,
    agent_id integer,
    user_id integer,
    status character varying(50),
    priority integer,
    payload jsonb,
    result jsonb,
    error_message text,
    created_at timestamp without time zone,
    started_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.migration_backup_tasks OWNER TO sutazai;

--
-- Name: migration_backup_users; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.migration_backup_users (
    id integer,
    username character varying(50),
    email character varying(100),
    password_hash character varying(255),
    is_active boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    is_admin boolean,
    last_login timestamp with time zone,
    failed_login_attempts integer,
    locked_until timestamp with time zone
);


ALTER TABLE public.migration_backup_users OWNER TO sutazai;

--
-- Name: model_deployments; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.model_deployments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    model_id uuid,
    deployment_name character varying(255) NOT NULL,
    environment character varying(50) NOT NULL,
    version character varying(50),
    status character varying(20) DEFAULT 'pending'::character varying,
    endpoint_url character varying(500),
    resource_allocation jsonb DEFAULT '{}'::jsonb,
    deployed_by uuid,
    deployed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.model_deployments OWNER TO sutazai;

--
-- Name: model_performance; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.model_performance (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    model_id uuid,
    metric_name character varying(100) NOT NULL,
    metric_value numeric(10,6),
    measurement_timestamp timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    test_dataset character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.model_performance OWNER TO sutazai;

--
-- Name: model_registry; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.model_registry (
    id integer NOT NULL,
    model_name character varying(255) NOT NULL,
    model_type character varying(100) NOT NULL,
    size_mb numeric(10,2),
    status character varying(50) DEFAULT 'available'::character varying,
    ollama_status character varying(50),
    usage_count integer DEFAULT 0,
    last_used timestamp without time zone,
    file_path text,
    parameters jsonb DEFAULT '{}'::jsonb,
    capabilities jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.model_registry OWNER TO sutazai;

--
-- Name: model_registry_id_seq; Type: SEQUENCE; Schema: public; Owner: sutazai
--

CREATE SEQUENCE public.model_registry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.model_registry_id_seq OWNER TO sutazai;

--
-- Name: model_registry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sutazai
--

ALTER SEQUENCE public.model_registry_id_seq OWNED BY public.model_registry.id;


--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.notification_settings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    notification_type character varying(50) NOT NULL,
    channel character varying(20) NOT NULL,
    enabled boolean DEFAULT true,
    settings jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_settings OWNER TO sutazai;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.notifications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    recipient_id uuid,
    notification_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message text,
    data jsonb DEFAULT '{}'::jsonb,
    status character varying(20) DEFAULT 'unread'::character varying,
    priority character varying(10) DEFAULT 'normal'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    read_at timestamp with time zone,
    expires_at timestamp with time zone
);


ALTER TABLE public.notifications OWNER TO sutazai;

--
-- Name: orchestration_sessions; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.orchestration_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    session_name character varying(255),
    task_description text NOT NULL,
    agents_involved jsonb DEFAULT '[]'::jsonb NOT NULL,
    strategy character varying(50) DEFAULT 'collaborative'::character varying,
    status character varying(50) DEFAULT 'pending'::character varying,
    progress numeric(5,2) DEFAULT 0.00,
    result jsonb,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE public.orchestration_sessions OWNER TO sutazai;

--
-- Name: queue_jobs; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.queue_jobs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    queue_name character varying(255) NOT NULL,
    job_type character varying(100) NOT NULL,
    payload jsonb NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    priority integer DEFAULT 5,
    attempts integer DEFAULT 0,
    max_attempts integer DEFAULT 3,
    retry_delay_seconds integer DEFAULT 60,
    error_message text,
    scheduled_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_max_attempts CHECK (((max_attempts >= 1) AND (max_attempts <= 10))),
    CONSTRAINT chk_priority CHECK (((priority >= 1) AND (priority <= 10)))
);


ALTER TABLE public.queue_jobs OWNER TO sutazai;

--
-- Name: resource_allocations; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.resource_allocations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    pool_id uuid,
    allocated_to character varying(50) NOT NULL,
    allocated_to_id uuid NOT NULL,
    allocated_amount numeric(10,2) NOT NULL,
    allocation_status character varying(20) DEFAULT 'active'::character varying,
    allocated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    released_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT chk_allocated_amount CHECK ((allocated_amount > (0)::numeric))
);


ALTER TABLE public.resource_allocations OWNER TO sutazai;

--
-- Name: resource_pools; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.resource_pools (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    pool_name character varying(255) NOT NULL,
    resource_type character varying(50) NOT NULL,
    total_capacity numeric(10,2),
    available_capacity numeric(10,2),
    reserved_capacity numeric(10,2),
    unit character varying(20),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.resource_pools OWNER TO sutazai;

--
-- Name: service_dependencies; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.service_dependencies (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    service_name character varying(255) NOT NULL,
    depends_on_service character varying(255) NOT NULL,
    dependency_type character varying(50) DEFAULT 'required'::character varying,
    health_impact character varying(20) DEFAULT 'critical'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.service_dependencies OWNER TO sutazai;

--
-- Name: service_health; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.service_health (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    service_name character varying(255) NOT NULL,
    service_type character varying(100),
    health_status character varying(20) NOT NULL,
    response_time_ms numeric(10,3),
    cpu_usage_percent numeric(5,2),
    memory_usage_mb numeric(10,2),
    error_rate_percent numeric(5,4),
    last_health_check timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.service_health OWNER TO sutazai;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    user_id integer,
    token character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    is_active boolean DEFAULT true,
    user_agent text,
    ip_address inet,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_accessed timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sessions OWNER TO sutazai;

--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: sutazai
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sessions_id_seq OWNER TO sutazai;

--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sutazai
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: system_alerts; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.system_alerts (
    id integer NOT NULL,
    alert_type character varying(100) NOT NULL,
    severity character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    source character varying(100),
    status character varying(50) DEFAULT 'active'::character varying,
    resolved_at timestamp without time zone,
    resolved_by integer,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_alerts OWNER TO sutazai;

--
-- Name: system_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: sutazai
--

CREATE SEQUENCE public.system_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_alerts_id_seq OWNER TO sutazai;

--
-- Name: system_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sutazai
--

ALTER SEQUENCE public.system_alerts_id_seq OWNED BY public.system_alerts.id;


--
-- Name: system_configuration; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.system_configuration (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    config_key character varying(255) NOT NULL,
    config_value text,
    config_type character varying(50) DEFAULT 'string'::character varying,
    description text,
    is_sensitive boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_by uuid
);


ALTER TABLE public.system_configuration OWNER TO sutazai;

--
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.system_metrics (
    id integer NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_value double precision NOT NULL,
    tags jsonb DEFAULT '{}'::jsonb,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_metrics OWNER TO sutazai;

--
-- Name: system_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: sutazai
--

CREATE SEQUENCE public.system_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_metrics_id_seq OWNER TO sutazai;

--
-- Name: system_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sutazai
--

ALTER SEQUENCE public.system_metrics_id_seq OWNED BY public.system_metrics.id;


--
-- Name: task_assignments; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.task_assignments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    task_id uuid,
    agent_id uuid,
    assigned_by uuid,
    assignment_status character varying(20) DEFAULT 'assigned'::character varying,
    priority_override integer,
    assigned_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    accepted_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE public.task_assignments OWNER TO sutazai;

--
-- Name: task_dependencies; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.task_dependencies (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    task_id uuid,
    depends_on_task_id uuid,
    dependency_type character varying(50) DEFAULT 'blocks'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.task_dependencies OWNER TO sutazai;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    agent_id integer,
    user_id integer,
    status character varying(50) DEFAULT 'pending'::character varying,
    priority integer DEFAULT 5,
    payload jsonb DEFAULT '{}'::jsonb,
    result jsonb,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    started_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.tasks OWNER TO sutazai;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: sutazai
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO sutazai;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sutazai
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: training_jobs; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.training_jobs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    job_name character varying(255) NOT NULL,
    model_type character varying(100) NOT NULL,
    dataset_path character varying(500),
    hyperparameters jsonb DEFAULT '{}'::jsonb,
    status character varying(20) DEFAULT 'pending'::character varying,
    progress numeric(5,2) DEFAULT 0.00,
    started_by uuid,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.training_jobs OWNER TO sutazai;

--
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.user_permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    permission_name character varying(100) NOT NULL,
    resource_type character varying(50),
    resource_id uuid,
    granted_by uuid,
    granted_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    CONSTRAINT chk_permission_expires CHECK (((expires_at IS NULL) OR (expires_at > granted_at)))
);


ALTER TABLE public.user_permissions OWNER TO sutazai;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.user_profiles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    first_name character varying(100),
    last_name character varying(100),
    display_name character varying(150),
    bio text,
    avatar_url character varying(500),
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    language character varying(10) DEFAULT 'en'::character varying,
    preferences jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_profiles OWNER TO sutazai;

--
-- Name: users; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_admin boolean DEFAULT false,
    last_login timestamp with time zone,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone
);


ALTER TABLE public.users OWNER TO sutazai;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: sutazai
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO sutazai;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sutazai
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vector_collections; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.vector_collections (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    collection_name character varying(255) NOT NULL,
    database_type character varying(50) NOT NULL,
    dimension integer NOT NULL,
    document_count integer DEFAULT 0,
    status character varying(50) DEFAULT 'active'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.vector_collections OWNER TO sutazai;

--
-- Name: workflow_executions; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.workflow_executions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    workflow_id uuid,
    triggered_by uuid,
    execution_status character varying(20) DEFAULT 'running'::character varying,
    current_step integer DEFAULT 0,
    total_steps integer,
    context jsonb DEFAULT '{}'::jsonb,
    result jsonb,
    error_message text,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp with time zone
);


ALTER TABLE public.workflow_executions OWNER TO sutazai;

--
-- Name: workflows; Type: TABLE; Schema: public; Owner: sutazai
--

CREATE TABLE public.workflows (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    workflow_definition jsonb NOT NULL,
    version integer DEFAULT 1,
    status character varying(20) DEFAULT 'active'::character varying,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.workflows OWNER TO sutazai;

--
-- Name: agent_executions id; Type: DEFAULT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.agent_executions ALTER COLUMN id SET DEFAULT nextval('public.agent_executions_id_seq'::regclass);


--
-- Name: agent_health id; Type: DEFAULT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.agent_health ALTER COLUMN id SET DEFAULT nextval('public.agent_health_id_seq'::regclass);


--
-- Name: agents id; Type: DEFAULT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.agents ALTER COLUMN id SET DEFAULT nextval('public.agents_id_seq'::regclass);


--
-- Name: chat_history id; Type: DEFAULT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.chat_history ALTER COLUMN id SET DEFAULT nextval('public.chat_history_id_seq'::regclass);


--
-- Name: model_registry id; Type: DEFAULT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.model_registry ALTER COLUMN id SET DEFAULT nextval('public.model_registry_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: system_alerts id; Type: DEFAULT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.system_alerts ALTER COLUMN id SET DEFAULT nextval('public.system_alerts_id_seq'::regclass);


--
-- Name: system_metrics id; Type: DEFAULT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.system_metrics ALTER COLUMN id SET DEFAULT nextval('public.system_metrics_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: agent_communication; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.agent_communication (id, from_agent_id, to_agent_id, message_type, message_body, status, priority, metadata, created_at, delivered_at, acknowledged_at) FROM stdin;
\.


--
-- Data for Name: agent_configurations; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.agent_configurations (id, agent_id, config_name, config_data, version, is_active, created_by, created_at, activated_at) FROM stdin;
\.


--
-- Data for Name: agent_executions; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.agent_executions (id, agent_id, task_id, status, input_data, output_data, execution_time, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: agent_health; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.agent_health (id, agent_id, status, last_heartbeat, cpu_usage, memory_usage, disk_usage, response_time, error_count, success_count, metadata, created_at, updated_at) FROM stdin;
1	1	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
2	2	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
3	3	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
4	4	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
5	5	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
6	4	healthy	2025-08-09 23:25:19.417967	25.50	512.70	0.00	0.125	0	0	{}	2025-08-09 23:25:19.417967	2025-08-09 23:25:19.417967
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.agents (id, name, type, description, endpoint, port, is_active, capabilities, created_at) FROM stdin;
1	health-monitor	monitoring	\N	http://health-monitor:8080	10210	t	["health_check", "metrics"]	2025-08-09 11:48:02.541621
2	task-coordinator	orchestration	\N	http://task-coordinator:8080	10450	t	["task_routing", "scheduling"]	2025-08-09 11:48:02.541621
3	ollama-service	llm	\N	http://ollama:11434	11434	t	["text_generation", "chat"]	2025-08-09 11:48:02.541621
4	hardware-resource-optimizer	optimization	\N	http://hardware-resource-optimizer:8080	11110	t	["resource_monitoring", "optimization"]	2025-08-09 11:48:02.541621
5	ai-agent-orchestrator	orchestration	\N	http://ai-agent-orchestrator:8080	8589	t	["agent_coordination", "task_routing"]	2025-08-09 11:48:02.541621
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.api_keys (id, user_id, key_name, key_hash, key_prefix, permissions, rate_limit_per_minute, last_used_at, is_active, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: api_usage_logs; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.api_usage_logs (id, endpoint, method, user_id, agent_id, response_code, response_time, request_size, response_size, ip_address, user_agent, headers, request_body, response_body, created_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.audit_logs (id, user_id, action, resource_type, resource_id, old_values, new_values, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: backup_executions; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.backup_executions (id, job_id, execution_status, backup_size_mb, duration_seconds, error_message, backup_location, checksum, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: backup_jobs; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.backup_jobs (id, job_name, backup_type, source_config, destination_config, schedule_cron, retention_days, status, last_run_at, next_run_at, created_at) FROM stdin;
\.


--
-- Data for Name: cache_entries; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.cache_entries (id, cache_key, cache_value, cache_type, ttl_seconds, access_count, last_accessed_at, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: chat_history; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.chat_history (id, user_id, message, response, agent_used, tokens_used, response_time, created_at) FROM stdin;
\.


--
-- Data for Name: data_pipelines; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.data_pipelines (id, pipeline_name, source_id, destination_id, pipeline_config, schedule_cron, status, last_run_at, next_run_at, created_at) FROM stdin;
\.


--
-- Data for Name: data_quality_checks; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.data_quality_checks (id, source_id, check_name, check_type, check_config, threshold_config, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: data_quality_results; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.data_quality_results (id, check_id, execution_timestamp, passed, score, details, metadata) FROM stdin;
\.


--
-- Data for Name: data_sources; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.data_sources (id, source_name, source_type, connection_string, credentials, schema_definition, status, last_sync_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.feature_flags (id, flag_name, description, is_enabled, rollout_percentage, target_users, conditions, created_at, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: incident_timeline; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.incident_timeline (id, incident_id, event_type, event_description, created_by, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: incidents; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.incidents (id, incident_title, description, severity, status, affected_services, assigned_to, reported_by, root_cause, resolution, created_at, resolved_at, updated_at) FROM stdin;
\.


--
-- Data for Name: integration_endpoints; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.integration_endpoints (id, endpoint_name, endpoint_type, base_url, authentication_config, headers_config, rate_limit_config, timeout_seconds, retry_config, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: integration_logs; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.integration_logs (id, endpoint_id, request_method, request_url, request_headers, request_body, response_status, response_headers, response_body, duration_ms, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: knowledge_documents; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.knowledge_documents (id, title, content_preview, full_content, document_type, source_path, collection_id, embedding_status, processed_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migration_backup_agent_executions; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.migration_backup_agent_executions (id, agent_id, task_id, status, input_data, output_data, execution_time, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: migration_backup_agent_health; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.migration_backup_agent_health (id, agent_id, status, last_heartbeat, cpu_usage, memory_usage, disk_usage, response_time, error_count, success_count, metadata, created_at, updated_at) FROM stdin;
1	1	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
2	2	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
3	3	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
4	4	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
5	5	healthy	2025-08-09 23:24:59.685658	0.00	0.00	0.00	0.000	0	0	{}	2025-08-09 23:24:59.685658	2025-08-09 23:24:59.685658
6	4	healthy	2025-08-09 23:25:19.417967	25.50	512.70	0.00	0.125	0	0	{}	2025-08-09 23:25:19.417967	2025-08-09 23:25:19.417967
\.


--
-- Data for Name: migration_backup_agents; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.migration_backup_agents (id, name, type, description, endpoint, port, is_active, capabilities, created_at) FROM stdin;
1	health-monitor	monitoring	\N	http://health-monitor:8080	10210	t	["health_check", "metrics"]	2025-08-09 11:48:02.541621
2	task-coordinator	orchestration	\N	http://task-coordinator:8080	10450	t	["task_routing", "scheduling"]	2025-08-09 11:48:02.541621
3	ollama-service	llm	\N	http://ollama:11434	11434	t	["text_generation", "chat"]	2025-08-09 11:48:02.541621
4	hardware-resource-optimizer	optimization	\N	http://hardware-resource-optimizer:8080	11110	t	["resource_monitoring", "optimization"]	2025-08-09 11:48:02.541621
5	ai-agent-orchestrator	orchestration	\N	http://ai-agent-orchestrator:8080	8589	t	["agent_coordination", "task_routing"]	2025-08-09 11:48:02.541621
\.


--
-- Data for Name: migration_backup_chat_history; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.migration_backup_chat_history (id, user_id, message, response, agent_used, tokens_used, response_time, created_at) FROM stdin;
\.


--
-- Data for Name: migration_backup_model_registry; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.migration_backup_model_registry (id, model_name, model_type, size_mb, status, ollama_status, usage_count, last_used, file_path, parameters, capabilities, created_at, updated_at) FROM stdin;
1	tinyllama	llm	637.00	active	loaded	0	\N	\N	{"parameters": "1.1B", "quantization": "Q4_0", "context_length": 2048}	[]	2025-08-09 23:24:07.022462	2025-08-09 23:24:07.022462
\.


--
-- Data for Name: migration_backup_sessions; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.migration_backup_sessions (id, user_id, token, expires_at, is_active, user_agent, ip_address, created_at, last_accessed) FROM stdin;
\.


--
-- Data for Name: migration_backup_system_alerts; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.migration_backup_system_alerts (id, alert_type, severity, title, description, source, status, resolved_at, resolved_by, metadata, created_at) FROM stdin;
1	database_test	info	Database Schema Initialization Complete	All tables created and initialized successfully	dba_admin	active	\N	\N	{}	2025-08-09 23:25:19.417967
\.


--
-- Data for Name: migration_backup_system_metrics; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.migration_backup_system_metrics (id, metric_name, metric_value, tags, recorded_at) FROM stdin;
\.


--
-- Data for Name: migration_backup_tasks; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.migration_backup_tasks (id, title, description, agent_id, user_id, status, priority, payload, result, error_message, created_at, started_at, completed_at) FROM stdin;
1	QA Test Task	Testing integer ID relationships	\N	1	pending	5	{}	\N	\N	2025-08-10 19:26:58.891629	\N	\N
\.


--
-- Data for Name: migration_backup_users; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.migration_backup_users (id, username, email, password_hash, is_active, created_at, updated_at, is_admin, last_login, failed_login_attempts, locked_until) FROM stdin;
2	system	system@sutazai.local	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewjyJyM7QK8kL5yC	t	2025-08-09 08:33:14.678865+00	2025-08-09 08:33:14.678865+00	f	\N	0	\N
4	testuser	test@example.com	$2b$12$Bb3F5df4b.a8srdVrs8tDeORK/f0.tQbfAMhf.WKHEdQAiGHHDtOO	t	2025-08-09 11:35:06.146473+00	2025-08-09 11:35:28.8902+00	f	2025-08-09 11:35:28.890943+00	0	\N
5	testuser3	test3@example.com	$2b$12$evgZb/VZLlUNKtPlMoBToO6OMYuRt63k9k0LwhzbOsModyr41UONW	t	2025-08-09 11:46:54.876466+00	2025-08-09 11:47:08.542303+00	f	2025-08-09 11:47:08.543288+00	0	\N
1	admin	admin@sutazai.local	$2b$12$NPu5JmL4gBSR21BQRYDoW.xzKoWyatlrbchYKuQes7kpsLb2zoBNG	t	2025-08-09 08:33:14.678865+00	2025-08-09 23:24:59.685658+00	t	\N	2	\N
7	dba_test	dba_test@sutazai.local	test_hash	t	2025-08-09 23:25:19.417967+00	2025-08-09 23:25:19.417967+00	f	\N	0	\N
\.


--
-- Data for Name: model_deployments; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.model_deployments (id, model_id, deployment_name, environment, version, status, endpoint_url, resource_allocation, deployed_by, deployed_at, created_at) FROM stdin;
\.


--
-- Data for Name: model_performance; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.model_performance (id, model_id, metric_name, metric_value, measurement_timestamp, test_dataset, metadata) FROM stdin;
\.


--
-- Data for Name: model_registry; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.model_registry (id, model_name, model_type, size_mb, status, ollama_status, usage_count, last_used, file_path, parameters, capabilities, created_at, updated_at) FROM stdin;
1	tinyllama	llm	637.00	active	loaded	0	\N	\N	{"parameters": "1.1B", "quantization": "Q4_0", "context_length": 2048}	[]	2025-08-09 23:24:07.022462	2025-08-09 23:24:07.022462
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.notification_settings (id, user_id, notification_type, channel, enabled, settings, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.notifications (id, recipient_id, notification_type, title, message, data, status, priority, created_at, read_at, expires_at) FROM stdin;
\.


--
-- Data for Name: orchestration_sessions; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.orchestration_sessions (id, session_name, task_description, agents_involved, strategy, status, progress, result, error_message, metadata, created_at, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: queue_jobs; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.queue_jobs (id, queue_name, job_type, payload, status, priority, attempts, max_attempts, retry_delay_seconds, error_message, scheduled_at, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: resource_allocations; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.resource_allocations (id, pool_id, allocated_to, allocated_to_id, allocated_amount, allocation_status, allocated_at, released_at, metadata) FROM stdin;
\.


--
-- Data for Name: resource_pools; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.resource_pools (id, pool_name, resource_type, total_capacity, available_capacity, reserved_capacity, unit, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_dependencies; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.service_dependencies (id, service_name, depends_on_service, dependency_type, health_impact, created_at) FROM stdin;
\.


--
-- Data for Name: service_health; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.service_health (id, service_name, service_type, health_status, response_time_ms, cpu_usage_percent, memory_usage_mb, error_rate_percent, last_health_check, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.sessions (id, user_id, token, expires_at, is_active, user_agent, ip_address, created_at, last_accessed) FROM stdin;
\.


--
-- Data for Name: system_alerts; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.system_alerts (id, alert_type, severity, title, description, source, status, resolved_at, resolved_by, metadata, created_at) FROM stdin;
1	database_test	info	Database Schema Initialization Complete	All tables created and initialized successfully	dba_admin	active	\N	\N	{}	2025-08-09 23:25:19.417967
2	schema_migration	info	Database Schema Migration Completed	Successfully migrated database from 10 tables to 47 tables with UUID primary keys and comprehensive indexing	Agent_7_Schema_Migrator	resolved	\N	\N	{"agent": "Agent_7", "tables_added": 37, "total_tables": 47, "migration_date": "2025-08-11"}	2025-08-11 18:33:13.122658
\.


--
-- Data for Name: system_configuration; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.system_configuration (id, config_key, config_value, config_type, description, is_sensitive, created_at, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.system_metrics (id, metric_name, metric_value, tags, recorded_at) FROM stdin;
\.


--
-- Data for Name: task_assignments; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.task_assignments (id, task_id, agent_id, assigned_by, assignment_status, priority_override, assigned_at, accepted_at, completed_at) FROM stdin;
\.


--
-- Data for Name: task_dependencies; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.task_dependencies (id, task_id, depends_on_task_id, dependency_type, created_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.tasks (id, title, description, agent_id, user_id, status, priority, payload, result, error_message, created_at, started_at, completed_at) FROM stdin;
1	QA Test Task	Testing integer ID relationships	\N	1	pending	5	{}	\N	\N	2025-08-10 19:26:58.891629	\N	\N
\.


--
-- Data for Name: training_jobs; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.training_jobs (id, job_name, model_type, dataset_path, hyperparameters, status, progress, started_by, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.user_permissions (id, user_id, permission_name, resource_type, resource_id, granted_by, granted_at, expires_at, is_active) FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.user_profiles (id, user_id, first_name, last_name, display_name, bio, avatar_url, timezone, language, preferences, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.users (id, username, email, password_hash, is_active, created_at, updated_at, is_admin, last_login, failed_login_attempts, locked_until) FROM stdin;
2	system	system@sutazai.local	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewjyJyM7QK8kL5yC	t	2025-08-09 08:33:14.678865+00	2025-08-09 08:33:14.678865+00	f	\N	0	\N
4	testuser	test@example.com	$2b$12$Bb3F5df4b.a8srdVrs8tDeORK/f0.tQbfAMhf.WKHEdQAiGHHDtOO	t	2025-08-09 11:35:06.146473+00	2025-08-09 11:35:28.8902+00	f	2025-08-09 11:35:28.890943+00	0	\N
5	testuser3	test3@example.com	$2b$12$evgZb/VZLlUNKtPlMoBToO6OMYuRt63k9k0LwhzbOsModyr41UONW	t	2025-08-09 11:46:54.876466+00	2025-08-09 11:47:08.542303+00	f	2025-08-09 11:47:08.543288+00	0	\N
1	admin	admin@sutazai.local	$2b$12$NPu5JmL4gBSR21BQRYDoW.xzKoWyatlrbchYKuQes7kpsLb2zoBNG	t	2025-08-09 08:33:14.678865+00	2025-08-09 23:24:59.685658+00	t	\N	2	\N
7	dba_test	dba_test@sutazai.local	test_hash	t	2025-08-09 23:25:19.417967+00	2025-08-09 23:25:19.417967+00	f	\N	0	\N
\.


--
-- Data for Name: vector_collections; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.vector_collections (id, collection_name, database_type, dimension, document_count, status, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workflow_executions; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.workflow_executions (id, workflow_id, triggered_by, execution_status, current_step, total_steps, context, result, error_message, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: sutazai
--

COPY public.workflows (id, name, description, workflow_definition, version, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Name: agent_executions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sutazai
--

SELECT pg_catalog.setval('public.agent_executions_id_seq', 1, false);


--
-- Name: agent_health_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sutazai
--

SELECT pg_catalog.setval('public.agent_health_id_seq', 6, true);


--
-- Name: agents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sutazai
--

SELECT pg_catalog.setval('public.agents_id_seq', 5, true);


--
-- Name: chat_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sutazai
--

SELECT pg_catalog.setval('public.chat_history_id_seq', 1, false);


--
-- Name: model_registry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sutazai
--

SELECT pg_catalog.setval('public.model_registry_id_seq', 1, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sutazai
--

SELECT pg_catalog.setval('public.sessions_id_seq', 1, false);


--
-- Name: system_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sutazai
--

SELECT pg_catalog.setval('public.system_alerts_id_seq', 2, true);


--
-- Name: system_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sutazai
--

SELECT pg_catalog.setval('public.system_metrics_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sutazai
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sutazai
--

SELECT pg_catalog.setval('public.users_id_seq', 8, true);


--
-- Name: agent_communication agent_communication_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.agent_communication
    ADD CONSTRAINT agent_communication_pkey PRIMARY KEY (id);


--
-- Name: agent_configurations agent_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.agent_configurations
    ADD CONSTRAINT agent_configurations_pkey PRIMARY KEY (id);


--
-- Name: agent_executions agent_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_pkey PRIMARY KEY (id);


--
-- Name: agent_health agent_health_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.agent_health
    ADD CONSTRAINT agent_health_pkey PRIMARY KEY (id);


--
-- Name: agents agents_name_key; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_name_key UNIQUE (name);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: api_usage_logs api_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.api_usage_logs
    ADD CONSTRAINT api_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_executions backup_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.backup_executions
    ADD CONSTRAINT backup_executions_pkey PRIMARY KEY (id);


--
-- Name: backup_jobs backup_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_pkey PRIMARY KEY (id);


--
-- Name: cache_entries cache_entries_cache_key_key; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.cache_entries
    ADD CONSTRAINT cache_entries_cache_key_key UNIQUE (cache_key);


--
-- Name: cache_entries cache_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.cache_entries
    ADD CONSTRAINT cache_entries_pkey PRIMARY KEY (id);


--
-- Name: chat_history chat_history_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.chat_history
    ADD CONSTRAINT chat_history_pkey PRIMARY KEY (id);


--
-- Name: data_pipelines data_pipelines_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.data_pipelines
    ADD CONSTRAINT data_pipelines_pkey PRIMARY KEY (id);


--
-- Name: data_quality_checks data_quality_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.data_quality_checks
    ADD CONSTRAINT data_quality_checks_pkey PRIMARY KEY (id);


--
-- Name: data_quality_results data_quality_results_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.data_quality_results
    ADD CONSTRAINT data_quality_results_pkey PRIMARY KEY (id);


--
-- Name: data_sources data_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_pkey PRIMARY KEY (id);


--
-- Name: feature_flags feature_flags_flag_name_key; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_flag_name_key UNIQUE (flag_name);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (id);


--
-- Name: incident_timeline incident_timeline_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.incident_timeline
    ADD CONSTRAINT incident_timeline_pkey PRIMARY KEY (id);


--
-- Name: incidents incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_pkey PRIMARY KEY (id);


--
-- Name: integration_endpoints integration_endpoints_endpoint_name_key; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.integration_endpoints
    ADD CONSTRAINT integration_endpoints_endpoint_name_key UNIQUE (endpoint_name);


--
-- Name: integration_endpoints integration_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.integration_endpoints
    ADD CONSTRAINT integration_endpoints_pkey PRIMARY KEY (id);


--
-- Name: integration_logs integration_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_pkey PRIMARY KEY (id);


--
-- Name: knowledge_documents knowledge_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.knowledge_documents
    ADD CONSTRAINT knowledge_documents_pkey PRIMARY KEY (id);


--
-- Name: model_deployments model_deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.model_deployments
    ADD CONSTRAINT model_deployments_pkey PRIMARY KEY (id);


--
-- Name: model_performance model_performance_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.model_performance
    ADD CONSTRAINT model_performance_pkey PRIMARY KEY (id);


--
-- Name: model_registry model_registry_model_name_key; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_model_name_key UNIQUE (model_name);


--
-- Name: model_registry model_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: orchestration_sessions orchestration_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.orchestration_sessions
    ADD CONSTRAINT orchestration_sessions_pkey PRIMARY KEY (id);


--
-- Name: queue_jobs queue_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.queue_jobs
    ADD CONSTRAINT queue_jobs_pkey PRIMARY KEY (id);


--
-- Name: resource_allocations resource_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.resource_allocations
    ADD CONSTRAINT resource_allocations_pkey PRIMARY KEY (id);


--
-- Name: resource_pools resource_pools_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.resource_pools
    ADD CONSTRAINT resource_pools_pkey PRIMARY KEY (id);


--
-- Name: resource_pools resource_pools_pool_name_key; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.resource_pools
    ADD CONSTRAINT resource_pools_pool_name_key UNIQUE (pool_name);


--
-- Name: service_dependencies service_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.service_dependencies
    ADD CONSTRAINT service_dependencies_pkey PRIMARY KEY (id);


--
-- Name: service_health service_health_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.service_health
    ADD CONSTRAINT service_health_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_token_key; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_token_key UNIQUE (token);


--
-- Name: system_alerts system_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_pkey PRIMARY KEY (id);


--
-- Name: system_configuration system_configuration_config_key_key; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.system_configuration
    ADD CONSTRAINT system_configuration_config_key_key UNIQUE (config_key);


--
-- Name: system_configuration system_configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.system_configuration
    ADD CONSTRAINT system_configuration_pkey PRIMARY KEY (id);


--
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- Name: task_assignments task_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_pkey PRIMARY KEY (id);


--
-- Name: task_dependencies task_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: training_jobs training_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.training_jobs
    ADD CONSTRAINT training_jobs_pkey PRIMARY KEY (id);


--
-- Name: agent_configurations uk_agent_config_name_version; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.agent_configurations
    ADD CONSTRAINT uk_agent_config_name_version UNIQUE (agent_id, config_name, version);


--
-- Name: service_dependencies uk_service_dependency; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.service_dependencies
    ADD CONSTRAINT uk_service_dependency UNIQUE (service_name, depends_on_service);


--
-- Name: notification_settings uk_user_notification_channel; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT uk_user_notification_channel UNIQUE (user_id, notification_type, channel);


--
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vector_collections vector_collections_collection_name_key; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.vector_collections
    ADD CONSTRAINT vector_collections_collection_name_key UNIQUE (collection_name);


--
-- Name: vector_collections vector_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.vector_collections
    ADD CONSTRAINT vector_collections_pkey PRIMARY KEY (id);


--
-- Name: workflow_executions workflow_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.workflow_executions
    ADD CONSTRAINT workflow_executions_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: idx_agent_communication_created; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_agent_communication_created ON public.agent_communication USING btree (created_at);


--
-- Name: idx_agent_communication_from_agent; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_agent_communication_from_agent ON public.agent_communication USING btree (from_agent_id);


--
-- Name: idx_agent_communication_status; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_agent_communication_status ON public.agent_communication USING btree (status);


--
-- Name: idx_agent_communication_to_agent; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_agent_communication_to_agent ON public.agent_communication USING btree (to_agent_id);


--
-- Name: idx_agent_executions_agent_id; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_agent_executions_agent_id ON public.agent_executions USING btree (agent_id);


--
-- Name: idx_agent_health_agent_id; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_agent_health_agent_id ON public.agent_health USING btree (agent_id);


--
-- Name: idx_agent_health_status; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_agent_health_status ON public.agent_health USING btree (status);


--
-- Name: idx_agents_type; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_agents_type ON public.agents USING btree (type);


--
-- Name: idx_api_usage_logs_created; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_api_usage_logs_created ON public.api_usage_logs USING btree (created_at);


--
-- Name: idx_api_usage_logs_endpoint; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_api_usage_logs_endpoint ON public.api_usage_logs USING btree (endpoint);


--
-- Name: idx_api_usage_logs_response_code; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_api_usage_logs_response_code ON public.api_usage_logs USING btree (response_code);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_created; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_audit_logs_created ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_cache_entries_accessed; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_cache_entries_accessed ON public.cache_entries USING btree (last_accessed_at);


--
-- Name: idx_cache_entries_expires; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_cache_entries_expires ON public.cache_entries USING btree (expires_at);


--
-- Name: idx_cache_entries_key; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_cache_entries_key ON public.cache_entries USING btree (cache_key);


--
-- Name: idx_chat_history_conversation; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_chat_history_conversation ON public.chat_history USING btree (user_id, created_at DESC) WHERE (user_id IS NOT NULL);


--
-- Name: idx_chat_history_user_id; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_chat_history_user_id ON public.chat_history USING btree (user_id);


--
-- Name: idx_incidents_assigned; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_incidents_assigned ON public.incidents USING btree (assigned_to);


--
-- Name: idx_incidents_created; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_incidents_created ON public.incidents USING btree (created_at);


--
-- Name: idx_incidents_severity; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_incidents_severity ON public.incidents USING btree (severity);


--
-- Name: idx_incidents_status; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_incidents_status ON public.incidents USING btree (status);


--
-- Name: idx_knowledge_documents_collection; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_knowledge_documents_collection ON public.knowledge_documents USING btree (collection_id);


--
-- Name: idx_knowledge_documents_status; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_knowledge_documents_status ON public.knowledge_documents USING btree (embedding_status);


--
-- Name: idx_knowledge_documents_type; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_knowledge_documents_type ON public.knowledge_documents USING btree (document_type);


--
-- Name: idx_model_registry_name; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_model_registry_name ON public.model_registry USING btree (model_name);


--
-- Name: idx_notifications_created; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_notifications_created ON public.notifications USING btree (created_at);


--
-- Name: idx_notifications_recipient; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_notifications_recipient ON public.notifications USING btree (recipient_id);


--
-- Name: idx_notifications_status; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_notifications_status ON public.notifications USING btree (status);


--
-- Name: idx_notifications_type; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_notifications_type ON public.notifications USING btree (notification_type);


--
-- Name: idx_orchestration_sessions_created; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_orchestration_sessions_created ON public.orchestration_sessions USING btree (created_at);


--
-- Name: idx_orchestration_sessions_status; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_orchestration_sessions_status ON public.orchestration_sessions USING btree (status);


--
-- Name: idx_queue_jobs_priority; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_queue_jobs_priority ON public.queue_jobs USING btree (priority);


--
-- Name: idx_queue_jobs_queue; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_queue_jobs_queue ON public.queue_jobs USING btree (queue_name);


--
-- Name: idx_queue_jobs_scheduled; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_queue_jobs_scheduled ON public.queue_jobs USING btree (scheduled_at);


--
-- Name: idx_queue_jobs_status; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_queue_jobs_status ON public.queue_jobs USING btree (status);


--
-- Name: idx_service_health_check; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_service_health_check ON public.service_health USING btree (last_health_check);


--
-- Name: idx_service_health_service; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_service_health_service ON public.service_health USING btree (service_name);


--
-- Name: idx_service_health_status; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_service_health_status ON public.service_health USING btree (health_status);


--
-- Name: idx_sessions_token; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_sessions_token ON public.sessions USING btree (token);


--
-- Name: idx_sessions_user_id; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_sessions_user_id ON public.sessions USING btree (user_id);


--
-- Name: idx_system_alerts_status; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_system_alerts_status ON public.system_alerts USING btree (status);


--
-- Name: idx_system_metrics_name; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_system_metrics_name ON public.system_metrics USING btree (metric_name);


--
-- Name: idx_system_metrics_recorded_at; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_system_metrics_recorded_at ON public.system_metrics USING btree (recorded_at);


--
-- Name: idx_tasks_agent_id; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_tasks_agent_id ON public.tasks USING btree (agent_id);


--
-- Name: idx_tasks_status; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_tasks_status ON public.tasks USING btree (status);


--
-- Name: idx_tasks_user_id; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_tasks_user_id ON public.tasks USING btree (user_id);


--
-- Name: idx_tasks_user_status_created; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_tasks_user_status_created ON public.tasks USING btree (user_id, status, created_at DESC) WHERE (user_id IS NOT NULL);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_is_admin; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_users_is_admin ON public.users USING btree (is_admin) WHERE (is_admin = true);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_vector_collections_status; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_vector_collections_status ON public.vector_collections USING btree (status);


--
-- Name: idx_vector_collections_type; Type: INDEX; Schema: public; Owner: sutazai
--

CREATE INDEX idx_vector_collections_type ON public.vector_collections USING btree (database_type);


--
-- Name: agents update_agents_updated_at; Type: TRIGGER; Schema: public; Owner: sutazai
--

CREATE TRIGGER update_agents_updated_at BEFORE UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tasks update_tasks_updated_at; Type: TRIGGER; Schema: public; Owner: sutazai
--

CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: sutazai
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: agent_executions agent_executions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agent_executions agent_executions_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: agent_health agent_health_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.agent_health
    ADD CONSTRAINT agent_health_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: backup_executions backup_executions_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.backup_executions
    ADD CONSTRAINT backup_executions_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.backup_jobs(id) ON DELETE CASCADE;


--
-- Name: chat_history chat_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.chat_history
    ADD CONSTRAINT chat_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: data_pipelines data_pipelines_destination_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.data_pipelines
    ADD CONSTRAINT data_pipelines_destination_id_fkey FOREIGN KEY (destination_id) REFERENCES public.data_sources(id) ON DELETE CASCADE;


--
-- Name: data_pipelines data_pipelines_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.data_pipelines
    ADD CONSTRAINT data_pipelines_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON DELETE CASCADE;


--
-- Name: data_quality_checks data_quality_checks_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.data_quality_checks
    ADD CONSTRAINT data_quality_checks_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.data_sources(id) ON DELETE CASCADE;


--
-- Name: data_quality_results data_quality_results_check_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.data_quality_results
    ADD CONSTRAINT data_quality_results_check_id_fkey FOREIGN KEY (check_id) REFERENCES public.data_quality_checks(id) ON DELETE CASCADE;


--
-- Name: incident_timeline incident_timeline_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.incident_timeline
    ADD CONSTRAINT incident_timeline_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.incidents(id) ON DELETE CASCADE;


--
-- Name: integration_logs integration_logs_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.integration_endpoints(id) ON DELETE CASCADE;


--
-- Name: knowledge_documents knowledge_documents_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.knowledge_documents
    ADD CONSTRAINT knowledge_documents_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.vector_collections(id) ON DELETE CASCADE;


--
-- Name: resource_allocations resource_allocations_pool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.resource_allocations
    ADD CONSTRAINT resource_allocations_pool_id_fkey FOREIGN KEY (pool_id) REFERENCES public.resource_pools(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: system_alerts system_alerts_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: tasks tasks_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: tasks tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: workflow_executions workflow_executions_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sutazai
--

ALTER TABLE ONLY public.workflow_executions
    ADD CONSTRAINT workflow_executions_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

